/*   Issuezilla in Java                                                       */
/*   COPYRIGHT 2005 JESSE WILSON                                              */
package ca.odell.issuezilla;

/**
 * Callback interface for the {@link IssuezillaXMLParser}.
 *
 * @author <a href="mailto:jesse@odel.on.ca">Jesse Wilson</a>
 */
public interface IssuezillaXMLParserHandler {
    
    /**
     * Handles the loading of the specified issue.
     */
    public void issueLoaded(Issue issue);
}
