/*   Issuezilla in Java                                                       */
/*   COPYRIGHT 2005 JESSE WILSON                                              */
package ca.odell.issuezilla;

import java.util.*;

/**
 * Reference to this issue's duplicate.
 *
 * @author <a href="mailto:jesse@odel.on.ca">Jesse Wilson</a>
 */
public class PeerIssue {
    private String issueId = null;
    private String who = null;
    private Date when = null;

    /**
     * user who created the duplicate.
     */
    public String getWho() {
        return who;
    }

    public void setWho(String who) {
        this.who = who;
    }

    /**
     * date the described change was made
     */
    public Date getWhen() {
        return when;
    }

    public void setWhen(Date when) {
        this.when = when;
    }

    /**
     * ID of the duplicate.
     */
    public String getIssueId() {
        return issueId;
    }

    public void setIssueId(String issueId) {
        this.issueId = issueId;
    }
}
