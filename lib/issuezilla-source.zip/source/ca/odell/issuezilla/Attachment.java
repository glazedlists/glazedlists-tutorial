/*   Issuezilla in Java                                                       */
/*   COPYRIGHT 2005 JESSE WILSON                                              */
package ca.odell.issuezilla;

import java.util.*;

/**
 * Data pertaining to attachments.  NOTE - some of these fields
 * are currently unimplemented (ispatch, filename, etc.).
 *
 * @author <a href="mailto:jesse@odel.on.ca">Jesse Wilson</a>
 */
public class Attachment {
    private String mimeType = null;
    private String attachId = null;
    private Date date = null;
    private String description = null;
    private String isPatch = null;
    private String filename = null;
    private String submitterId = null;
    private String submitterUsername = null;
    private String data = null;
    private String attachmentIzUrl = null;

    /**
     * Mime type for the attachment.
     */
    public String getMimeType() {
        return mimeType;
    }

    public void setMimeType(String mimeType) {
        this.mimeType = mimeType;
    }

    /**
     * A unique id for this attachment.
     */
    public String getAttachId() {
        return attachId;
    }

    public void setAttachId(String attachId) {
        this.attachId = attachId;
    }

    /**
     * Timestamp of when added 'yyyy-mm-dd hh:mm'
     */
    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    /**
     * Short description for attachment.
     */
    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    /**
     * Whether attachment is a patch file.
     */
    public String getIsPatch() {
        return isPatch;
    }

    public void setIsPatch(String isPatch) {
        this.isPatch = isPatch;
    }

    /**
     * Filename of attachment.
     */
    public String getFilename() {
        return filename;
    }

    public void setFilename(String filename) {
        this.filename = filename;
    }

    /**
     * Issuezilla ID of attachement submitter.
     */
    public String getSubmitterId() {
        return submitterId;
    }

    public void setSubmitterId(String submitterId) {
        this.submitterId = submitterId;
    }

    /**
     * username of attachement submitter.
     */
    public String getSubmitterUsername() {
        return submitterUsername;
    }

    public void setSubmitterUsername(String submitterUsername) {
        this.submitterUsername = submitterUsername;
    }

    /**
     * Encoded attachment.
     */
    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    /**
     * URL to attachment in iz.
     */
    public String getAttachmentIzUrl() {
        return attachmentIzUrl;
    }

    public void setAttachmentIzUrl(String attachmentIzUrl) {
        this.attachmentIzUrl = attachmentIzUrl;
    }
}
